///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "camera.h" 


#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	//Initialize the ShaderManager pointer
	m_pShaderManager = pShaderManager;

	//Create a new instance of ShaderMeshes
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		//Set default values for texture IDs and tags
		m_textureIDs[i].tag = "/0";//Default tag
		m_textureIDs[i].ID = -1;//Default texture ID
	}

	//Set the number of loaded textures to )
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// free the allocated objects
	m_pShaderManager = NULL;

	//Check if not null before deleting
	if (NULL != m_basicMeshes)
	{
		delete m_basicMeshes;//Delete the ShapeMeshes instance
		m_basicMeshes = NULL;//Set to null after delete
	}

	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}


/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;// Variable to check if texture creation is successful
	bReturn = CreateGLTexture(
		"textures/wood.jpg", "handle");//Loads wood texture for the plane

	bReturn = CreateGLTexture(
		"textures/plastic.jpg", "spoon");// Loads plastic texture for the cylinder

	bReturn = CreateGLTexture(
		"textures/rubber.jpg", "weight");// Loads rubber texture for the cone

	bReturn = CreateGLTexture(
		"textures/shiny plastic.jpg", "cone");// Loads shiny plastic texture for the tapered cylinder(cone)

	bReturn = CreateGLTexture(
		"textures/shiny rock.jpg", "rock");// Loads shiny rock texture for the rock

	bReturn = CreateGLTexture(
		"textures/fabric.jpg", "hair tie");// Loads fabric texture for the hair tie

	bReturn = CreateGLTexture(
		"textures/paper.jpg", "paper");// Loads paper texture for the plane

	bReturn = CreateGLTexture(
		"textures/wall.jpg", "wall");// Loads wall texture for the plane

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	
	BindGLTextures();
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/
/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	{

		//Define materaial properties for the spoon handle
		OBJECT_MATERIAL woodMaterial;
		woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
		woodMaterial.ambientStrength = 0.2f;
		woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
		woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
		woodMaterial.shininess = 0.3;
		woodMaterial.tag = "wood";

		m_objectMaterials.push_back(woodMaterial);

		//Define materaial properties for the spoon scoop
		OBJECT_MATERIAL rubberspoonMaterial;
		rubberspoonMaterial.ambientColor = glm::vec3(0.135f, 0.2225f, 0.1575);
		rubberspoonMaterial.ambientStrength = 0.2f;
		rubberspoonMaterial.diffuseColor = glm::vec3(0.54f,0.89f, 0.63f);
		rubberspoonMaterial.specularColor = glm::vec3(0.316228f, 0.316228f, 0.316228f);
		rubberspoonMaterial.shininess = 0.02f;
		rubberspoonMaterial.tag = "rubberspoon";

		m_objectMaterials.push_back(rubberspoonMaterial);

		//Define materaial properties for the cone
		OBJECT_MATERIAL orangeplasticMaterial;
		orangeplasticMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
		orangeplasticMaterial.ambientStrength = 0.2f;
		orangeplasticMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.0f);
		orangeplasticMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.5f);
		orangeplasticMaterial.shininess = 12.5f;
		orangeplasticMaterial.tag = "orangeplastic";

		m_objectMaterials.push_back(orangeplasticMaterial);

		//Define materaial properties for the hair tie
		OBJECT_MATERIAL greentieMaterial;
		greentieMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
		greentieMaterial.ambientStrength = 0.2f;
		greentieMaterial.diffuseColor = glm::vec3(0.4f, 0.5f, 0.4f);
		greentieMaterial.specularColor = glm::vec3(0.04f, 0.7f, 0.04f);
		greentieMaterial.shininess = 0.5f;
		greentieMaterial.tag = "greentie";

		m_objectMaterials.push_back(greentieMaterial);

		//Define materaial properties for the rock
		OBJECT_MATERIAL stoneMaterial;
		stoneMaterial.ambientColor = glm::vec3(0.3f,0.4f, 0.5f);
		stoneMaterial.ambientStrength = 0.7f;
		stoneMaterial.diffuseColor = glm::vec3(0.714f, 0.4284f,	0.6f);
		stoneMaterial.specularColor = glm::vec3(0.8f, 0.6f,0.4);
		stoneMaterial.shininess = 135.0f;
		stoneMaterial.tag = "stone";

		m_objectMaterials.push_back(stoneMaterial);

		//Define materaial properties for the backdrop
		OBJECT_MATERIAL backdropMaterial;
		backdropMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
		backdropMaterial.ambientStrength = 0.2f;
		backdropMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
		backdropMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
		backdropMaterial.shininess = 0.3;
		backdropMaterial.tag = "backdrop";

		m_objectMaterials.push_back(backdropMaterial);
	}

}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black 

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	m_pShaderManager->setVec3Value("lightSources[0].position", 3.0f, 14.0f, 0.0f);//set position of light the source
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.005f, 0.005f, 0.005f);//Add some color to the ambient light for the scene
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.1f, 0.1f, 0.1f);//set diffuse color of the light sourse
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.0f, 0.0f, 0.0f);//set specular color of the light source
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 8.0f);//Set focal strength of the light source
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.002f);//Set specular intensity of the source

	m_pShaderManager->setVec3Value("lightSources[1].position", -3.0f, 14.0f, 0.0f); // set position of light the source
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.005f, 0.005f, 0.005f);//Add some color to the ambient light for the scene
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.2f, 0.2f, 0.2f); // set diffuse color of the light source
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.0f, 0.0f, 0.0f);//set specular color of the light source
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 8.0f);//Set focal strength of the light source
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.002f);//Set specular intensity of the source
	
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.6f, 5.0f, 6.0f); // set position of light the source
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.01f, 0.01f, 0.01f);//Add some color to the ambient light for the scene
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.15f, 0.15f, 0.15f);//set diffuse color of the light sourse
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.1f, 0.1f, 0.1f);//set specular color of the light source
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 4.0f);//Set focal strength of the light source
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.001f);//Set specular intensity of the source

	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 3.0f, 20.0f);// 4 iterations needed for lighting to work******
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.01f, 0.01f, 0.01f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.6f, 0.6f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.01f, 0.01f, 0.01f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 2.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.002f);
	
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	//load the textures for th e3D scene
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	glm::mat4 scale{};
	glm::mat4 rotation{};
	glm::mat4 rotation2{};
	glm::mat4 translation{};
	glm::mat4 model{};

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(80.0f, 1.0f, 80.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Set texture used by the shader for the plane.
	//This binds the paper texture to the mesh.
	SetShaderTexture("paper");

	//Set UV scale for the texture mapping.
	//Scales UV corrdinates by 1.0 so no scale is applied
	SetTextureUVScale(1.0, 1.0);

	//set shader material to "wood"
	//this applies the "wood" material to the shader fo rendering the mesh
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
/////////////////////////////////////////////////////////////////////////////////

		// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(80.0f, 1.0f, 80.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 15.0f, -8.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wall");
	SetTextureUVScale(8.0, 8.0);
	SetShaderMaterial("backdrop");

	// draw the mesh with transformation values - this plane is used for the backdrop
	m_basicMeshes->DrawPlaneMesh();

	/******************************************************************/
	//Wooden laddel Handle

	// set the XYZ scale for the mesh		//Elongated handle
	scaleXYZ = glm::vec3(0.4f, 11.0f, 0.4f);//Set the scale of the handle to be proportional to the 2D scene

	//set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;//Lays the handle on the plane
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 60.0f;//Sets handle diagonlly across plane pointing from the upper right to the bottom left of the plane

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.0f, 0.5f, 1.5f);//Sets position on plane to be to the upper right side of the plane

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Set texture used by the shader for the handle.
	//This binds the wood handle texture to the mesh.
	SetShaderTexture("handle");

	//Set UV scale for the texture mapping.
	//Scales UV corrdinates by 1.0 so no scale is applied
	SetTextureUVScale(1.0, 1.0);

	//set shader material to "wood"
	//this applies the "wood" material to the shader for rendering the mesh
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	// set the XYZ scale for the mesh	   //Scoop end of the laddle
	scaleXYZ = glm::vec3(3.0f, 3.0f, 3.0f);//Set the scale of the handle to be proportional to the 2D scene

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(11.0f, 0.0f, -1.f);//Set scoop end location at the upper right side of the plane

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Set texture used by the shader for the half sphere.
	//This binds plastic spoon texture to the mesh.
	SetShaderTexture("spoon");

	//Set UV scale for the texture mapping.
	//Scales UV corrdinates by 1.0 so no scale is applied
	SetTextureUVScale(1.0, 1.0);

	//set shader material to "rubberspoon"
	//this applies the "rubberspoon" material to the shader for rendering the mesh
	SetShaderMaterial("rubberspoon");

	// draw the mesh with transformation values
	m_basicMeshes->DrawHalfSphereMesh();

	/******************************************************************/
	// set the XYZ scale for the mesh       //Piece to connect the scoop to the handle
	scaleXYZ = glm::vec3(0.7f, 2.5f, 0.8f);//Set the scale of the handle to be proportional to the 2D scene

	// set the XYZ rotation for the mesh
	//Connect tapered cylinder to the cylinder handle and connects to the scoop
	XrotationDegrees = 90.0f;//Lays the connecting piece on the plane 
	YrotationDegrees = 12.2f;
	ZrotationDegrees = 60.0f;// Lines up with cylinder handle and sphere scoop

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(9.1f, 1.0f, 0.3f);//Set location to the upper right side of the plane

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Set texture used by the shader for the tapered cylinder portion of the spoon.
	//This binds the plastic texture to the mesh.
	SetShaderTexture("spoon");

	//Set UV scale for the texture mapping.
	//Scales UV corrdinates by 1.0 so no scale is applied
	SetTextureUVScale(1.0, 1.0);

	//set shader material to "rubberspoon"
	//this applies the "rubberspoon" material to the shader for rendering the mesh
	SetShaderMaterial("rubberspoon");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

	/******************************************************************/

	// set the XYZ scale for the mesh	  
	scaleXYZ = glm::vec3(1.0f, 0.4f, 0.7f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3 (3.0f, 0.19f, 6.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Set texture used by the shader for the torus.
	//This binds fabirc texture to the mesh.
	SetShaderTexture("hair tie");

	//Set UV scale for the texture mapping.
	//Scales UV corrdinates by 1.0 so no scale is applied
	SetTextureUVScale(1.0, 1.0);

	//set shader material to "greentie"
	//this applies the "greentie" material to the shader for rendering the mesh
	SetShaderMaterial("greentie");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();

	/******************************************************************/
	// set the XYZ scale for the mesh     
	scaleXYZ = glm::vec3(3.5f, 9.0f, 3.5f);

	// set the XYZ rotation for the mesh
	
	XrotationDegrees = 0.0f;//
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;// 

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 0.01f, 0.7f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Set texture used by the shader for the tapered cylinder.
	//This binds the cone texture to the mesh.
	SetShaderTexture("cone");

	//Set UV scale for the texture mapping.
	//Scales UV corrdinates by 1.0 so no scale is applied
	SetTextureUVScale(1.0, 1.0);

	//set shader material to "orangeplastic"
	//this applies the "orangeplastic" material to the shader for rendering the mesh
	SetShaderMaterial("orangeplastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

		/******************************************************************/
	// set the XYZ scale for the mesh     
	scaleXYZ = glm::vec3(1.5f, 1.5f, 1.5f);

	// set the XYZ rotation for the mesh

	XrotationDegrees = 0.0f;//
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;// 

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 9.6f, 0.7f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Set texture used by the shader for the sphere.
	//This binds the rock texture to the mesh.
	SetShaderTexture("rock");

	//Set UV scale for the texture mapping.
	//Scales UV corrdinates by 1.0 so no scale is applied
	SetTextureUVScale(1.0, 1.0);

	//set shader material to "stone"
	//this applies the "stone" material to the shader for rendering the mesh
	SetShaderMaterial("stone");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/

}
